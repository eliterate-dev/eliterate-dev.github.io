self.assetsManifest = {
  "version": "8wKol7xY",
  "assets": [
    {
      "hash": "sha256-Tp5DMyNGSdN59rh4JSxgN4hxdNdoUukTyibnS+ajzT0=",
      "url": "404.html"
    },
    {
      "hash": "sha256-WoKo5831/xRHN1BREciMWVND4zpqA8Xk+OxzIkITQ4s=",
      "url": "CNAME"
    },
    {
      "hash": "sha256-x4Pzik/y5TV5UvNatT4fF39WIf4RYXQ/+tfloRc8fJk=",
      "url": "Eliterate.WebAssembly.styles.css"
    },
    {
      "hash": "sha256-nIt4Js5mbG/FcyZACk1+y2FKrBNGGaVQdQTab+c6rb4=",
      "url": "_framework/Codespirals.Base.Shared.096v7rpcvz.wasm"
    },
    {
      "hash": "sha256-q1zlGwW5rNMwpuX6GDqiu1LdhpG20VmRpih6u1kCcQA=",
      "url": "_framework/Codespirals.CardGames.FlipSeven.3aw1retx8i.wasm"
    },
    {
      "hash": "sha256-DGzXQQ9l1l01ZYRIzrK18CBVCRTfGpVw7qNlOU2h+8w=",
      "url": "_framework/Codespirals.CardGames.Poker.cgkycld8y1.wasm"
    },
    {
      "hash": "sha256-Z9kGaV1AeXrJYsjWSHPn0ofpctYiC8EI5Ru1RD/Y/CE=",
      "url": "_framework/Codespirals.CardGames.Shared.psx276d0kn.wasm"
    },
    {
      "hash": "sha256-0zSjOJljVxn3Zx2YYfiZShcpoCSP9KP1lGtE8YCQj5c=",
      "url": "_framework/Codespirals.VideoGames.MineSweeper.xf7qbegxc2.wasm"
    },
    {
      "hash": "sha256-8AoLY7fNOGNhI95kPbvyM95LcoKFJz8a+sgTj+g1vCs=",
      "url": "_framework/Eliterate.WebAssembly.sh3hnyenhb.wasm"
    },
    {
      "hash": "sha256-Dh57L9nxu+ri9x4unzWqtqArq1FNLNpXHLdawKAE0i4=",
      "url": "_framework/Markdig.qqvxzo214f.wasm"
    },
    {
      "hash": "sha256-+jTgKXgH0mjBgPb7RlqtNKyTltfZAQr0CreG8VenVdA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ilstdubmvo.wasm"
    },
    {
      "hash": "sha256-YznfV3cxktF6q0rydkpY2OSaZ9s1i4spercWa0eR9u8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.v5t7qwtktv.wasm"
    },
    {
      "hash": "sha256-mYE15Q+tfM2fHGq72S80Mlq6BF5piCMbb5tjPEPhwEM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.396zkwqv3y.wasm"
    },
    {
      "hash": "sha256-vRs4J3QVidy7cUPoDD/d2GEEB65bahMWa4LOzRmmehs=",
      "url": "_framework/Microsoft.AspNetCore.Components.zwevfipsag.wasm"
    },
    {
      "hash": "sha256-yqBP2nTwgGNLI5ZUlBsk59F2x3QiIshT1JcPEAGv378=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.iugyzp5bsa.wasm"
    },
    {
      "hash": "sha256-5kw+ZCHspYGQGLAQbmRBTguQ0jxAmVo47jZsZoE98Q8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.ero76l0otg.wasm"
    },
    {
      "hash": "sha256-d4x5KTkCLjfmeJYVNdU4tb3cS498XA5JxV6+PY05vhQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.xyejtlvkam.wasm"
    },
    {
      "hash": "sha256-4sau3YdUIGsejALOxmSaLEzGBz3FkrvFKl1a9KWPVr8=",
      "url": "_framework/Microsoft.Extensions.Configuration.y4v13oz4tz.wasm"
    },
    {
      "hash": "sha256-GhXmlZ0NaNgERZeOJvEDaFmmJYtsekuYDoqqEu4dkps=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.2m0gaxgl7m.wasm"
    },
    {
      "hash": "sha256-xdOn1q3YXQCqR0HdpwiFxw5iUIIJnGcREBIwOsDiI8A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.32b9wzs1da.wasm"
    },
    {
      "hash": "sha256-mXu8FP5HfT1aSxfRZNAaj3YhndCA53DegBtcW+W8++g=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.t7src6hxrx.wasm"
    },
    {
      "hash": "sha256-IrOQsIN9TeNSHqc4dW0hJCUXMfnxToSrZtBU0Z5tOyo=",
      "url": "_framework/Microsoft.Extensions.Logging.elyoyzaqer.wasm"
    },
    {
      "hash": "sha256-0w5dbSASTFWbjj1vK2/QZr2b6YIz2Eqs6X1p507AgiA=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.9104winsv9.wasm"
    },
    {
      "hash": "sha256-FZQziLJhlVF882N//H8zBUBt+nKbFjM3mSHNRepfiYw=",
      "url": "_framework/Microsoft.Extensions.Options.dysuems8p7.wasm"
    },
    {
      "hash": "sha256-2hCO4H8mexhSknMrGLLyeFBenBB6+EyaF/GABYiSFwI=",
      "url": "_framework/Microsoft.Extensions.Primitives.yybdz8bjuf.wasm"
    },
    {
      "hash": "sha256-cwR8EG01BGjctiJNl8rDA8n/Y+lCWTgaPq95qS4DElk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.h3txawygj0.wasm"
    },
    {
      "hash": "sha256-2T7G3HRbuwPaXQnS79/KZ2f0ol27uTd4vD6PeagdnKc=",
      "url": "_framework/Microsoft.JSInterop.r3mplozra9.wasm"
    },
    {
      "hash": "sha256-fOAcPcocA2hm+RTCZUCHHgAhRAwDqEyJgyVQTgOLSfk=",
      "url": "_framework/System.Collections.Concurrent.c0nw0xs7do.wasm"
    },
    {
      "hash": "sha256-j17DWec02xuCQHuG8x51zSkh7mOPFke9LHFX/nRPL44=",
      "url": "_framework/System.Collections.Immutable.lzrj5qgrc3.wasm"
    },
    {
      "hash": "sha256-ebqMHKDknow2SvYL1jORSeLUirS1e4bd18XnS/PV4wk=",
      "url": "_framework/System.Collections.NonGeneric.lp6i0yg01h.wasm"
    },
    {
      "hash": "sha256-u7INKAmf5w/zIMT2jBhNmwnN4rmWtj5uFjhG9SpqM/w=",
      "url": "_framework/System.Collections.Specialized.x5vapy57tl.wasm"
    },
    {
      "hash": "sha256-WrmQIaargjk2WeClFA/ODAtrayJpZQxbHE0IFGA/fYE=",
      "url": "_framework/System.Collections.m5ldlmwfnh.wasm"
    },
    {
      "hash": "sha256-gQN2gPhhaPkqpzqSXfjkn73i4ueHcxDXAZa4KPZ5G+I=",
      "url": "_framework/System.ComponentModel.Primitives.t5vj7e80zt.wasm"
    },
    {
      "hash": "sha256-6yOCqh0lDWorBAGXZI7Z5U8PUp09YqiRuMY16pfoiQY=",
      "url": "_framework/System.ComponentModel.TypeConverter.3yi4jyf1iv.wasm"
    },
    {
      "hash": "sha256-FlqirVL9sIZuu5B2uysMetgDBYcJW58SWqLwNYQFKzY=",
      "url": "_framework/System.ComponentModel.e6bm8wniqf.wasm"
    },
    {
      "hash": "sha256-szCyEwhqmInxvzD4SQpFP53aR+OoZvruQ7zTWqO3iZk=",
      "url": "_framework/System.Console.1715e3waf1.wasm"
    },
    {
      "hash": "sha256-Exr7usKEpZTKszlznexb503jWxdm+6JRTx4YuWLWkIU=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.d0y3j5rtmf.wasm"
    },
    {
      "hash": "sha256-7N+scuN8nmiU+QbLyZpP/FeRS5FYzMOKMTSW7NAJetA=",
      "url": "_framework/System.IO.Pipelines.s624opig07.wasm"
    },
    {
      "hash": "sha256-YPV5s4dtMIBpQWKN0EUSkE7s62xERnbesUXDq8MKcgA=",
      "url": "_framework/System.Linq.Expressions.kff9zv2h8c.wasm"
    },
    {
      "hash": "sha256-6IIsdVeG8WEBAjb3GVRtNHqJzibym6OFV6G4m1Vl974=",
      "url": "_framework/System.Linq.cn65qq5qop.wasm"
    },
    {
      "hash": "sha256-nrKYE5t5K9UQrg7oRbyAufOy1isxDOp6UwsmLYnZbZA=",
      "url": "_framework/System.Memory.qtn0ennx4i.wasm"
    },
    {
      "hash": "sha256-6sHd+R4Sw3tGUIUJm3KsLpUBxIoCVP4qDBOf09AihRc=",
      "url": "_framework/System.Net.Http.Json.mt8hn9094g.wasm"
    },
    {
      "hash": "sha256-9WewELzyXgsN9RNbwJzXezEPHnDBQQUQYYtutC2GNmg=",
      "url": "_framework/System.Net.Http.hlb9telx36.wasm"
    },
    {
      "hash": "sha256-0p7v5NjlejQKpS8GlJwDS/9AQUEPZgL4EKqAqDwKe84=",
      "url": "_framework/System.Net.Primitives.uhdmdhe7b7.wasm"
    },
    {
      "hash": "sha256-h2OzLIJxWzc2zqA6Ar5BcGX7S7z5GaUohnvT8hNe+nA=",
      "url": "_framework/System.ObjectModel.31eqa050x1.wasm"
    },
    {
      "hash": "sha256-Sda6OLPUn3Fuq5Z66hYGEKEq2Di8BfsdcLe8w7WoG3Y=",
      "url": "_framework/System.Private.CoreLib.9g4b320ji8.wasm"
    },
    {
      "hash": "sha256-ngLeT/pksvgF17oxWpP+JI+y0UaztASY4F2uyONz3Ys=",
      "url": "_framework/System.Private.Uri.6itlawb4je.wasm"
    },
    {
      "hash": "sha256-kXxOqCCKAa9Kae9L0uOFJh3gLdRMpnT0fGDYznQvTmo=",
      "url": "_framework/System.Runtime.57pozdlp9y.wasm"
    },
    {
      "hash": "sha256-Cp2bQOeRFVxMIA/IQbNc6pVyPdKopwM4EnwXZAse2KM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.uzoakn3mog.wasm"
    },
    {
      "hash": "sha256-hRKk/mTbKOvEiiMNlxO5KeZXI1qIZfVKPN5bbnFRTUI=",
      "url": "_framework/System.Runtime.InteropServices.v3fgp5l84q.wasm"
    },
    {
      "hash": "sha256-0Ft8otSyBLY3Xf1wCa28JH48CeCqnc1LVF55TTXbifc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.g04uo13c1r.wasm"
    },
    {
      "hash": "sha256-FrsOY8zOQD81TGKDEh0mP3ZICBl00LE3furOw7bToxY=",
      "url": "_framework/System.Security.Cryptography.6wps1yap4a.wasm"
    },
    {
      "hash": "sha256-xfdGWjORdXQ2LCLBEeazY5q9WKpDRphdCfHkREu7Dqo=",
      "url": "_framework/System.Text.Encodings.Web.15hk4o8waa.wasm"
    },
    {
      "hash": "sha256-e2oPGqv+ZLpxMA3b/h065497RrEW20QAxeBSpa7zQEc=",
      "url": "_framework/System.Text.Json.nt1l6qk3ml.wasm"
    },
    {
      "hash": "sha256-xmHmDKeH1TTdTnbLYW/i71bKRSfrAaU6Atp0HnRUA7w=",
      "url": "_framework/System.Text.RegularExpressions.q8gc57icsc.wasm"
    },
    {
      "hash": "sha256-tD0l8jkHGArxjxeVQBljWjCbOFmMS0giqeAQ9574Nek=",
      "url": "_framework/System.Threading.0bgjpol6rw.wasm"
    },
    {
      "hash": "sha256-TbXBiQa38E2TrjWSwZYk9l9sTztp8pQ4MLJyVPBpaEk=",
      "url": "_framework/System.nnqvudo0vd.wasm"
    },
    {
      "hash": "sha256-1xlHuu1iNOJiMMz2BCq95uekwHf6pdpTcgVNKVBboPs=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Ft9fk3R1ObzPuYTb94o2OAj8fm7AEVZDIijMtM/C/7Q=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-kkp5wX0htwkBcZt5WmEiKmhBqjqdCJtGc+koldfyoDQ=",
      "url": "_framework/dotnet.native.ikrs475e5v.js"
    },
    {
      "hash": "sha256-iQOJ2Ignl/X3n6mOHRQ4zWYcute0MGlaiRFi2J3HXWk=",
      "url": "_framework/dotnet.native.veuqw8a0w9.wasm"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ujkOK+XBNg5VRnG3oDLifBKO3ZgoVWP4xv10PfnaELQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-CiUxaZEOt0w0+nveHmAOJIHGEJdF77H9s5d6afIgMK4=",
      "url": "fonts/help-me/HelpMe.ttf"
    },
    {
      "hash": "sha256-SQPWMCRo96cs1so1Q9nnN1ajLL2uH9TjAiHkRzD5p9w=",
      "url": "fonts/help-me/License.txt"
    },
    {
      "hash": "sha256-/fvx4ATm2QZ5iKWTphnLcou8Feq87TrbjXfH+uPwclM=",
      "url": "images/ascii/totodile.txt"
    },
    {
      "hash": "sha256-rQpFzOfA7FfHoprj+iZdH4MJkYhrpQhaE+6I8fkEt0c=",
      "url": "images/gifs/AuntyDonna_square.gif"
    },
    {
      "hash": "sha256-sRcVJujiS9Fy+GfH+2ycmSncOqHREiK0tmGtlrVDV+k=",
      "url": "images/icons/logo-126.png"
    },
    {
      "hash": "sha256-TgKHM6tGSEVSX8R2fkdV58CNow7wPd1xnjazfJ52Gt4=",
      "url": "images/icons/logo-256.png"
    },
    {
      "hash": "sha256-vfX+C761Lx5Gsi5zw84el89DAEfwMtnFXlFsXN7fQFE=",
      "url": "images/icons/logo-32.png"
    },
    {
      "hash": "sha256-tvy4gsmcKJQSOIXxAlOyMAJpGTBL7wVb5YXzTo3206E=",
      "url": "images/icons/logo-64.png"
    },
    {
      "hash": "sha256-WyNzvNA2f1QfcVroADbbtXCYVyagCX7SSO5mixCL3vk=",
      "url": "images/memes/trying_to_find_the_guy_who_did_this.jpg"
    },
    {
      "hash": "sha256-x3VY3fFK5JrqHYKbLj9w+icBouYh+KGgQLIR3EcOXIM=",
      "url": "images/pictures/BOTAR.jpg"
    },
    {
      "hash": "sha256-37OyzhnUPuGy5+wWs4aE585zHWKQivzKISlkVUpaj3M=",
      "url": "images/pictures/Cat_biting.jpg"
    },
    {
      "hash": "sha256-uCzUpUHAZ6HlKw7BNgMsCus1xZDO1VpZah31DfEnsMs=",
      "url": "images/pictures/Cat_on_tower.jpg"
    },
    {
      "hash": "sha256-0uE/v9/LoJw/MWpO/H0hvaVkin7Qtmw0C4BIidnz5+E=",
      "url": "images/pictures/I_made_this.jpg"
    },
    {
      "hash": "sha256-MnrY6zwdXQYSeX/H0DzQRgSc9gwh/8DWcOiIh6e3YV8=",
      "url": "images/pictures/Prague_charles_bridge.jpg"
    },
    {
      "hash": "sha256-RxGrbal1R2UUQIkNalXW0z9EywTvJNfr5/IwRTA/O1o=",
      "url": "images/pictures/eliterate.svg"
    },
    {
      "hash": "sha256-WjgJSfiFsuy2dhgcw4RLo117cnNnTWmJriA5gEz/Jkw=",
      "url": "images/pictures/eliterate_qr.png"
    },
    {
      "hash": "sha256-Bqe6j+0dFsSL/CF0XMnl00NSynZHvZtouG7bANslev8=",
      "url": "images/pictures/swiss_flag.jpg"
    },
    {
      "hash": "sha256-yFxPCC+a4/f+O96e6bwGBtEdQIQG1TphS9jyoeXobUo=",
      "url": "images/pictures/us_flag.jpg"
    },
    {
      "hash": "sha256-ieXblNXTGpzEWU1Tg4e+q7Q7Zd5FQ15+FzLKeb0QteI=",
      "url": "images/textures/beige-paper.png"
    },
    {
      "hash": "sha256-U5fCw1STFDlmFxGIfhXtVDoNnMgJNnrY/TkVaOyi0rI=",
      "url": "images/textures/brick-wall-dark.png"
    },
    {
      "hash": "sha256-7cjounW7TpJNjU91ZpILqMgBaIDVqrzzBw9LPpzEXh8=",
      "url": "images/textures/cardboard-flat.png"
    },
    {
      "hash": "sha256-dqxerw3g0EFSTTAOY6isqVM/zlRy9EyRHyK14da2TrA=",
      "url": "images/textures/clean-gray-paper.png"
    },
    {
      "hash": "sha256-bqeT9QsgoKHuwsQzI/d+qIM70Fq4Cwr2svT3mC5cbXo=",
      "url": "images/textures/cream-paper.png"
    },
    {
      "hash": "sha256-iqBX7bYW7pm40SSoASPUqKgcLYoI4yStFTD+ZwEzfEE=",
      "url": "images/textures/dark-leather.png"
    },
    {
      "hash": "sha256-ahBy0LUoa3ZylloadfhQutgkA+RJYmbSY1lSKeBlblk=",
      "url": "images/textures/dark-wood.png"
    },
    {
      "hash": "sha256-Ju537WvrQMC8TWE9LLP+dbbpRyWdcAN/WjuOpLRfD04=",
      "url": "images/textures/diagmonds.png"
    },
    {
      "hash": "sha256-tCF78lP5NPxufO4g8H1YMZk8AMHpN5ARPzbk7lRGU0Y=",
      "url": "images/textures/handmade-paper.png"
    },
    {
      "hash": "sha256-o0CBSn+MOXLUgsva9CSNtKU8k1iOz6sNvCU6Jw1jKoY=",
      "url": "images/textures/light-paper-fibers.png"
    },
    {
      "hash": "sha256-zXR8zey2F0YrxCAImQtofrVlAKuMVPk9Kyj+769AryA=",
      "url": "images/textures/lined-paper-2.png"
    },
    {
      "hash": "sha256-/SIg979Tz2u+Z5+ZnyEueUg3egFGpQ9PZFIO0MpBL4M=",
      "url": "images/textures/lined-paper.png"
    },
    {
      "hash": "sha256-f+nuYw9Uk2R1BKb8dKgGHUrVcCj9jluW23XSuRaeFFM=",
      "url": "images/textures/notebook-dark.png"
    },
    {
      "hash": "sha256-6F6Q2apJqiOKDt0w8aX6mj+M/SyPmRKKXeD2d4Zxlxs=",
      "url": "images/textures/notebook.png"
    },
    {
      "hash": "sha256-ZkdkCMJzhns4ms/Eg91B99CpDeIyIEFSSCgNO8AMkAg=",
      "url": "images/textures/paper-2.png"
    },
    {
      "hash": "sha256-vBpQtB2DUniUs2X0LSr2Kp8/jEIYieHq4S17vmpTvHA=",
      "url": "images/textures/paper-3.png"
    },
    {
      "hash": "sha256-Ph5kP8E/G0Jv+6pGYTKGH4KhPu5/uIU2WdK3Qy+DqwQ=",
      "url": "images/textures/paper.png"
    },
    {
      "hash": "sha256-AfLsnUHCveQ4/91A2dzqev/Z8C0T9SNTCOg/4NM68gY=",
      "url": "images/textures/wine-cork.png"
    },
    {
      "hash": "sha256-vIAPf3cCf5S61ZpTVWFHoBvU0sFxyhqnFJqUx0yybzc=",
      "url": "images/textures/wood.png"
    },
    {
      "hash": "sha256-mWaLS2uYjroI94gH26wPMhBtx6rwZOvWoME2pJ/zLOE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": "js/scripts.js"
    },
    {
      "hash": "sha256-VEU0/oaMWzo34BIWDYM1CWNrLG0k4mpGODGC3Br/f10=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-W3KBnziveDNrBmsCZXNiibAL1smNQkIkP58yC+dgJ30=",
      "url": "posts/About.md"
    },
    {
      "hash": "sha256-3JtJzhYDNdcnt4ivSq0nVhTDYTk/WXWV7BX0zrNvL/Q=",
      "url": "posts/AiStatement.md"
    },
    {
      "hash": "sha256-djWT1roJEpfRoESHb8PkC0P89t1L7HnXzkS+/vBm5nc=",
      "url": "posts/CV.md"
    },
    {
      "hash": "sha256-GIQyADdvghyu2orelZihms47v+FdcrFhOF9rIac15bE=",
      "url": "posts/Design.md"
    },
    {
      "hash": "sha256-Lu2x6aWPOriaehRk9kYgW4A/y4icuSiDMhEBU6je43I=",
      "url": "posts/Me.md"
    },
    {
      "hash": "sha256-aEzG0QK2G72ptOC9jyyGXg0sk/dmNi7TRwTpQLLDMm0=",
      "url": "posts/OnEffort.md"
    },
    {
      "hash": "sha256-5J4q1GqkYTxDJzS3KgM3aafNoM9nmqCh5LVSRYwqusQ=",
      "url": "posts/Post_1.md"
    },
    {
      "hash": "sha256-sEpfKjLbBBDrI0roS2RPj9/eWXdtDBGgRVlPSZJS9R8=",
      "url": "posts/metadata.json"
    },
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": "posts/toys.md"
    },
    {
      "hash": "sha256-0qauigQIqI9dzOs/929fOajsojYovOeZW2lKCmZIdRA=",
      "url": "resources/credits.json"
    },
    {
      "hash": "sha256-iifVtGhKZ1nMFmzKrkPTVHTM+fx+oD9kegn7+YQWyoI=",
      "url": "resources/navlinks.json"
    },
    {
      "hash": "sha256-sYJ3bWFIfADbxvV6gdgbcYt6fOEyv0A2BMnWSEGOjKk=",
      "url": "resources/plans.json"
    },
    {
      "hash": "sha256-e/10xGx8Z3kjhqHxqwr9+dLVJ6TJNMrzFSYjhHEykss=",
      "url": "resources/quotes.json"
    },
    {
      "hash": "sha256-aFtsqEDO5BalfYW1tIvjqhKdNGiPRfuJc4pmIFGjk4c=",
      "url": "resources/songquotes.json"
    },
    {
      "hash": "sha256-nwT3PDvtM1REBquYfhAuWQNfXZuAItmcWixNTJZHL5g=",
      "url": "resources/taglines.json"
    },
    {
      "hash": "sha256-S6C3FaG/4U2g11qLTpJeoav4JJeAt3lkX4dGBVfE2Ro=",
      "url": "resources/toys.json"
    }
  ]
};
